package com.ghostscypher.learning2

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class Learning2ApplicationTests {

	@Test
	fun contextLoads() {
	}

}
