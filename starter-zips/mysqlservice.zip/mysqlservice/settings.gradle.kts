rootProject.name = "mysqlservice"
