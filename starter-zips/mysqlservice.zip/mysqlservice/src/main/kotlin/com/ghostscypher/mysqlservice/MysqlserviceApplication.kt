package com.ghostscypher.mysqlservice

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class MysqlserviceApplication

fun main(args: Array<String>) {
	runApplication<MysqlserviceApplication>(*args)
}
