rootProject.name = "planefinder"
