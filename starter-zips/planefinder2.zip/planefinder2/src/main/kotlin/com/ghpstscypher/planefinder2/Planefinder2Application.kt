package com.ghpstscypher.planefinder2

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class Planefinder2Application

fun main(args: Array<String>) {
	runApplication<Planefinder2Application>(*args)
}
